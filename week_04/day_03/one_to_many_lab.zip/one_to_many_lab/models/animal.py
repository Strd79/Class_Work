class Animal:

    def __init__(self, name, age, breed, owner, id = None):
        self.name = name
        self.age = age
        self.breed = breed
        self.owner = owner
        self.id = id
        